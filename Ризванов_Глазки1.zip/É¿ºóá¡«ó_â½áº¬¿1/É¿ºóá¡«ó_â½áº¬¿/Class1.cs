﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ризванов_Глазки
{
    internal class Class1
    {
    }
}
